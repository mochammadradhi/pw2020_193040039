<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>

  <table>
    <tr>
      <td>
        <h2>Kuliah</h2>
      </td>
      <td>
        <a href="Kuliah/Pertemuan 9/">Petemuan 9</a>
        <a href="Kuliah/Pertemuan 10/">Petemuan 10</a>
        <a href="Kuliah/Pertemuan 11/">Petemuan 11</a>
        <a href="Kuliah/Pertemuan 12/">Petemuan 12</a>
        <a href="Kuliah/Pertemuan 13/">Petemuan 13</a>
      </td>
    </tr>
    <tr>
      <td>
        <h2>Praktikum</h2>
      </td>
      <td>
        <a href="Praktikum/P5_PW_193040039/">Praktikum Petemuan 5</a>
        <a href="Praktikum/P6_PW_193040039/">Praktikum Petemuan 6</a>
        <a href="Praktikum/P7_PW_193040039/">Praktikum Petemuan 7</a>
      </td>
    </tr>
  </table>
</body>

</html>